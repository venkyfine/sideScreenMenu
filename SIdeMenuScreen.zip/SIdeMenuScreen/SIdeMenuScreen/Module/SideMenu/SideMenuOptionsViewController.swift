//
//  SideMenuOptionsViewController.swift
//  SIdeMenuScreen

import UIKit

class SideMenuOptionsViewController: UIViewController {

    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(SideMenuInformationCell.self)
        tblView.register(SideMenuDiscloureTableViewCell.self)
        tblView.register(SideMenuSeperatorTableViewCell.self)
        dropShadow()
        // Do any additional setup after loading the view.
    }
    
    
    func dropShadow() {
        contentView.layer.masksToBounds = false
        contentView.layer.shadowOffset = CGSize(width: 2, height: 0)
        contentView.layer.shadowColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1).cgColor
        contentView.layer.shadowOpacity = 0.29
        contentView.layer.shadowPath = nil
    }
    
}

extension SideMenuOptionsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let option = SideMenuOptions.allCases[indexPath.row]
        switch  option {
        case .scanHistory, .instrumentInfo, .syncHistory, .preferances:
            let cell : SideMenuDiscloureTableViewCell = tableView.cellForItemAtIndexPath(indexPath: indexPath)
            cell.option = option
            return cell
        case .seperator:
            let cell : SideMenuSeperatorTableViewCell = tableView.cellForItemAtIndexPath(indexPath: indexPath)
            return cell
        case .help, .requestSupport, .appTour, .logout:
            let cell : SideMenuInformationCell = tableView.cellForItemAtIndexPath(indexPath: indexPath)
            cell.option = option
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return SideMenuOptions.allCases.count
    }

}
