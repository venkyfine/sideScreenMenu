//
//  SideMenuInformationCell.swift
//  SIdeMenuScreen

import UIKit

class SideMenuInformationCell: UITableViewCell, NibLoadableView, ReusableView{

    @IBOutlet weak var lblTitle: UILabel!
    
    var option: SideMenuOptions! {
        didSet {
            self.lblTitle.text = option.rawValue
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
